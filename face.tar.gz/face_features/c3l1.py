# importing the module
import cv2
from math import sqrt

def distance(x1, y1, x2, y2):
	return sqrt((y2-y1)**2 + (x2-x1)**2)

def difference(c1, c2):
	d = 0
	for i in range (len(c1)):
		d+= distance(c1[i][0], c1[i][1], c2[i][0], c2[i][1])
	return d

def click_event(event, x, y, flags, params):
	if event == cv2.EVENT_LBUTTONDOWN:
		if toggle:
			coordinates1.append((x,y))
		else:
			coordinates2.append((x,y))

		font = cv2.FONT_HERSHEY_SIMPLEX
		if toggle:
			cv2.putText(f1, '.', (x-5, y), font, 1, (0, 0, 255), 3)
			cv2.imshow('image', f1)
		else:
			cv2.putText(f2, '.', (x-5, y), font, 1, (0, 0, 255), 3)
			cv2.imshow('image', f2)
	
toggle = True
coordinates1 = []
coordinates2 = []

f1 = cv2.imread('/usercode/data/f1.png')
cv2.imshow('image', f1)
cv2.setMouseCallback('image', click_event)
cv2.waitKey(0)
cv2.destroyAllWindows()
toggle = not toggle
f2 = cv2.imread('/usercode/data/f2.png')
cv2.imshow('image', f2)
cv2.setMouseCallback('image', click_event)
cv2.waitKey(0)
cv2.destroyAllWindows()

if (len(coordinates1) != len(coordinates2)):
	print("Error: No. of features selected for both faces are unequal.")
else:
	print(int(difference(coordinates1, coordinates2)/len(coordinates1)))